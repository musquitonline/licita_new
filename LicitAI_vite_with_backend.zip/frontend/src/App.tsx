import { useState } from "react";
function Button({ children, onClick, className="" }: any) { return <button onClick={onClick} className={"px-3 py-2 bg-blue-600 text-white rounded "+className}>{children}</button> }
function Card({children, className=""}: any) { return <div className={"bg-white rounded shadow p-4 "+className}>{children}</div> }
export default function App() {
  const [logged, setLogged] = useState(false);
  const [chat, setChat] = useState("");
  const [messages, setMessages] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const handleSend = async () => {
    if (!chat) return;
    setMessages([...messages, { role: "user", text: chat }]);
    setChat("");
    setLoading(true);
    try {
      const res = await fetch("/api/chat", { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify({prompt: chat}) });
      const data = await res.json();
      setMessages((msgs) => [...msgs, { role: "assistant", text: data.reply }]);
    } catch (e) {
      setMessages((msgs) => [...msgs, { role: "assistant", text: "Erro no servidor (mock)." }]);
    } finally { setLoading(false); }
  };
  if (!logged) {
    return (<div className="flex items-center justify-center min-h-screen"><Card className="w-[380px]"><h1 className="text-2xl font-bold text-center text-blue-700 mb-4">LicitAI</h1><input className="w-full mb-2 p-2 border rounded" placeholder="E-mail" type="email" /><input className="w-full mb-4 p-2 border rounded" placeholder="Senha" type="password" /><Button className="w-full" onClick={() => setLogged(true)}>Entrar</Button></Card></div>);
  }
  return (<div className="min-h-screen p-6"><header className="flex justify-between items-center mb-6"><h1 className="text-2xl font-bold text-blue-700">LicitAI Dashboard</h1><Button onClick={() => setLogged(false)}>Sair</Button></header><div className="grid grid-cols-1 md:grid-cols-3 gap-4"><Card className="col-span-1"><h2 className="text-lg font-semibold mb-2">Upload de Edital</h2><label className="w-full block"><input id="file" type="file" accept="application/pdf" className="hidden" onChange={async (e:any)=>{const f = e.target.files[0]; if(!f) return; const form = new FormData(); form.append('file', f); await fetch('/api/upload', { method: 'POST', body: form }); alert('Upload enviado (mock).'); }} /><div onClick={()=>document.getElementById('file')?.click()} className="cursor-pointer px-3 py-2 border rounded text-center text-sm bg-gray-100">Escolher arquivo PDF</div></label><p className="text-sm text-gray-600 mt-2">Faça o upload do edital para análise automática.</p></Card><Card className="col-span-2"><h2 className="text-lg font-semibold mb-2">Assistente de Geração</h2><div className="h-[300px] overflow-y-auto border rounded-md p-3 bg-white mb-3">{messages.map((m, i) => (<div key={i} className={`mb-2 ${m.role === 'user' ? 'text-right' : 'text-left'}`}><span className={`inline-block px-3 py-2 rounded-xl ${m.role === 'user' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-800'}`}>{m.text}</span></div>))}{loading && <div className="flex justify-center">Processando...</div>}</div><div className="flex gap-2"><textarea className="flex-1 p-2 border rounded" placeholder="Digite aqui sua solicitação..." value={chat} onChange={(e)=>setChat(e.target.value)} /><Button onClick={handleSend}>Enviar</Button></div></Card></div><div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4"><Card><h3 className="font-semibold mb-2">Documentos Gerados</h3><ul className="space-y-2"><li className="flex items-center justify-between border-b pb-2"><span>Proposta_01.pdf</span><button className="px-2 py-1 border rounded text-sm">Exportar</button></li></ul></Card><Card><h3 className="font-semibold mb-2">Alertas e Prazos</h3><p className="text-sm text-gray-600">Próxima sessão: 15/10/2025 - 09:00</p><p className="text-sm text-gray-600">Prazo para impugnação: até 11/10/2025</p></Card></div></div>);
}
